from distutils.filelist import findall
from unittest import case
import scrapy
import re

def no_accent_vietnamese(s):
    s = re.sub(r'[àáạảãâầấậẩẫăằắặẳẵ]', 'a', s)
    s = re.sub(r'[ÀÁẠẢÃĂẰẮẶẲẴÂẦẤẬẨẪ]', 'A', s)
    s = re.sub(r'[èéẹẻẽêềếệểễ]', 'e', s)
    s = re.sub(r'[ÈÉẸẺẼÊỀẾỆỂỄ]', 'E', s)
    s = re.sub(r'[òóọỏõôồốộổỗơờớợởỡ]', 'o', s)
    s = re.sub(r'[ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ]', 'O', s)
    s = re.sub(r'[ìíịỉĩ]', 'i', s)
    s = re.sub(r'[ÌÍỊỈĨ]', 'I', s)
    s = re.sub(r'[ùúụủũưừứựửữ]', 'u', s)
    s = re.sub(r'[ƯỪỨỰỬỮÙÚỤỦŨ]', 'U', s)
    s = re.sub(r'[ỳýỵỷỹ]', 'y', s)
    s = re.sub(r'[ỲÝỴỶỸ]', 'Y', s)
    s = re.sub(r'[Đ]', 'D', s)
    s = re.sub(r'[đ]', 'd', s)
    marks_list = [u'\u0300', u'\u0301', u'\u0302', u'\u0303', u'\u0306',u'\u0309', u'\u0323']
    for mark in marks_list:
        s = s.replace(mark, '')
    return s

class Covid19Spider(scrapy.Spider):
    name = 'covid19'
    allowed_domains = ['www.web.archive.org/']
    start_urls = ['https://web.archive.org/web/20210907023426/https://ncov.moh.gov.vn/vi/web/guest/dong-thoi-gian']

    def parse(self, response):
        regex1 = r'\S ([0-9]+.[0-9]+) \S'
        regex2 = r'(TP\s*.*\s[\)])'
        regex3 = r'([a-zA-Z]*\s.*?)\s[\(]'
        regex4 = r'\d+[0-9.]*'
        
    
        for row in response.xpath("//div[@class = 'timeline-detail']"):
            res_dst = dict()
            time = row.xpath(".//div/h3/text()").get()
            newCases = row.xpath(".//div/p[2]/text()").get()
            newCases = re.findall(regex1, newCases)
            
            city_cases = row.xpath(".//div[@class ='timeline-content']/p[3]/text()").get()
            city_cases = no_accent_vietnamese(city_cases)
            city_cases = re.findall(regex2,city_cases)
            
            if city_cases != []:
                city =re.findall(regex3, city_cases[0])
                cases = re.findall(regex4, city_cases[0])
                for i in range(len(city)):
                    res_dst[city[i]] = cases[i]
                
                yield {
                    'time' : time,
                    'newCases_total' : newCases[0],
                    'case_by_city' : res_dst
                }
            
        next_page = response.xpath("//ul[@class ='lfr-pagination-buttons pager']/li[2]/a/@href").get()
        if next_page:
            yield scrapy.Request(url=next_page, callback= self.parse)